package dataBean;



import java.util.ArrayList;

public class Data {
	private ArrayList<Double> x = new ArrayList<Double>();
	private double y;
	private ArrayList<Double> Mus = new ArrayList<Double>();
	public ArrayList<Double> getX() {
		return x;
	}
	public void setX(ArrayList<Double> x) {
		this.x = x;
	}
	public double getY() {
		return y;
	}
	public void setY(double y) {
		this.y = y;
	}
	public ArrayList<Double> getMus() {
		return Mus;
	}
	public void setMus(ArrayList<Double> mus) {
		Mus = mus;
	}
	
	

}
