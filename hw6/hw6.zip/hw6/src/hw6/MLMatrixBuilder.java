package hw6;



public interface MLMatrixBuilder {

	
	public void readFile(String name);
	
}
